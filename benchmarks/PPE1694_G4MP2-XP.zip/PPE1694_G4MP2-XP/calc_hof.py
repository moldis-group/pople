import os
import numpy as np
import pandas as pd
from pople import au2kcm
from pople import HOF_atoms, dH_atoms
from pople import uniqatoms, HLC_g4mp2

# This code reads U0, UT and HT from 'PPE1694_G4MP2-XP.csv' and 
# 'ATOMS_G4MP2-XP.csv'and calculates atomization energy and formation 
# enthalpy of all atoms 

print_geom='false' # Set to 'true' for printing geometries
print_freq='false' # Set to 'true' for printing frequencies

pd.set_option("display.max_colwidth", 100000)

def strip_geom(geom):
    geom_line=geom.strip().split(',')

    charge=int(geom_line[0])
    geom_line.pop(0)

    multip=int(geom_line[0])
    geom_line.pop(0)

    Nat = int((len(geom_line))/4)
    isatom = 'false'
    if Nat == 0:
        isatom = 'true'

    sym=[]
    X=[]
    Y=[]
    Z=[]

    for iat in range(0,len(geom_line),4):
        sym.append(geom_line[iat])

    for iat in range(1,len(geom_line),4):
        X.append(geom_line[iat])
    for iat in range(2,len(geom_line),4):
        Y.append(geom_line[iat])
    for iat in range(3,len(geom_line),4):
        Z.append(geom_line[iat])
    
    return charge, multip, Nat, isatom, sym, X, Y, Z

# Load data from csv
mols = pd.read_csv('PPE1694_G4MP2-XP.csv')
atoms = pd.read_csv('ATOMS_G4MP2-XP.csv')

# Loop over all molecules in the file
N_mol = len(mols)

for i_mol in range(N_mol):

    U0_mol=mols['U0'][i_mol:i_mol+1]
    U0_mol=U0_mol.to_string(index=False)
    U0_mol=float(U0_mol)
    
    HT_mol=mols['HT'][i_mol:i_mol+1]
    HT_mol=HT_mol.to_string(index=False)
    HT_mol=float(HT_mol)
    
    geom=mols['Geometry'][i_mol:i_mol+1]
    geom=geom.to_string(index=False)
 
    # Strip the geometry block
    charge, multip, Nat, isatom, sym, X, Y, Z = strip_geom(geom)

    print(' Molecule: {:5d}'.format(i_mol+1))
    if ( print_geom == 'true' ):
        print(' {:5d}'.format(Nat))
        print(' {:5d}{:5d}'.format(charge,multip))
        for iat in range(Nat):
            print(' {:4s}{:15.8f}{:15.8f}{:15.8f}'.format(sym[iat],float(X[iat]),float(Y[iat]),float(Z[iat])))

    if ( print_freq == 'true' ):
        freq=mols['Frequencies'][i_mol:i_mol+1]
        freq=freq.to_string(index=False)
        freq=freq.strip().split(',')
        print('')
        print(' Frequencies [cm^-1]')
        for f in freq:
            print(' {:15.8f}'.format(float(f)))
    
    # Unique atom data
    uniq = uniqatoms(sym) 
    N_ua = uniq["N_ua"]       # No. of unique atoms
    ua   = uniq["uniq_sym"]   # unique atoms
    ua_N = uniq["uan"]        # unique atom frequencies
    
    # Atomization energy
    U0_mol_AE=0
    for i_ua in range(int(N_ua)):
        at=atoms[atoms['Atom'] == (ua[i_ua])]
        atU=at['U0'].to_string(index=False)
        U0_mol_AE=U0_mol_AE+float(atU)*ua_N[i_ua]
    
    U0_mol_AE=U0_mol_AE-U0_mol  
    
    # Standard formation enthalpy
    HT_form = 0
    for i_ua in range(int(N_ua)):
       HOF_0K     = HOF_atoms(ua[i_ua])
       dH_298K_0K = dH_atoms(ua[i_ua])
       HT_form = HT_form + ua_N[i_ua] * ( HOF_0K - dH_298K_0K )
    
    HT_form = HT_form + (HT_mol - U0_mol) - U0_mol_AE
    
    print('')
    print(' Atomization energy is          {:12.4f} hartree, {:12.4f} kcal/mol'.format(U0_mol_AE, U0_mol_AE*au2kcm) )
    print(' Standard formation enthalpy is {:12.4f} hartree, {:12.4f} kcal/mol'.format(HT_form, HT_form*au2kcm) )
    print('')
