import os
import numpy as np
import pandas as pd
from pople import au2kcm
from pople import HOF_atoms, dH_atoms
from pople import uniqatoms, HLC_g4mp2

# This code reads U0, UT and HT from 'G305_g4mp2xp.csv' and 
# 'ATOMS_g4mp2xp.csv'and calculates atomization energy and formation 
# enthalpy of all molecules. Experimental values are also printed.

print_geom='true' # Set to 'true' for printing geometries in g4mp2_geom.xyz
print_freq='false' # Set to 'true' for printing frequencies in g4mp2_freq.dat

pd.set_option("display.max_colwidth", 100000)

def strip_geom(geom):
    geom_line=geom.strip().split(',')

    charge=int(geom_line[0])
    geom_line.pop(0)

    multip=int(geom_line[0])
    geom_line.pop(0)

    Nat = int((len(geom_line))/4)
    isatom = 'false'
    if Nat == 0:
        isatom = 'true'

    sym=[]
    X=[]
    Y=[]
    Z=[]

    for iat in range(0,len(geom_line),4):
        sym.append(geom_line[iat])
    for iat in range(1,len(geom_line),4):
        X.append(geom_line[iat])
    for iat in range(2,len(geom_line),4):
        Y.append(geom_line[iat])
    for iat in range(3,len(geom_line),4):
        Z.append(geom_line[iat])
    
    return charge, multip, Nat, isatom, sym, X, Y, Z

# Load data from csv
mols = pd.read_csv('G305_g4mp2xp.csv')
atoms = pd.read_csv('ATOMS_g4mp2xp.csv')

# Loop over all molecules in the file
N_mol = len(mols)

print(' #Mol.      Atm. E      Form. H        Exp. form. H [all in kcal/mol]')

# Output geometry
if ( print_geom == 'true' ):
    geomfile=open('g4mp2_geom.xyz','w')

# Output frequencies
if ( print_freq == 'true' ):
    freqfile=open('g4mp2_freq.dat','w')

for i_mol in range(N_mol):

    U0_mol=mols['U0'][i_mol:i_mol+1]
    U0_mol=U0_mol.to_string(index=False)
    U0_mol=float(U0_mol)
    
    HT_mol=mols['HT'][i_mol:i_mol+1]
    HT_mol=HT_mol.to_string(index=False)
    HT_mol=float(HT_mol)
    
    exp=mols['expt'][i_mol:i_mol+1]
    exp=exp.to_string(index=False)
    exp=float(exp)
    
    geom=mols['Geometry'][i_mol:i_mol+1]
    geom=geom.to_string(index=False)
 
    # Strip the geometry block
    charge, multip, Nat, isatom, sym, X, Y, Z = strip_geom(geom)
    
    # Unique atom data
    uniq = uniqatoms(sym) 
    N_ua = uniq["N_ua"]       # No. of unique atoms
    ua   = uniq["uniq_sym"]   # unique atoms
    ua_N = uniq["uan"]        # unique atom frequencies
    
    # Atomization energy
    U0_mol_AE=0
    for i_ua in range(int(N_ua)):
        at=atoms[atoms['Atom'] == (ua[i_ua])]
        atU=at['U0'].to_string(index=False)
        U0_mol_AE=U0_mol_AE+float(atU)*ua_N[i_ua]
    
    U0_mol_AE=U0_mol_AE-U0_mol  

    job=mols['job'][i_mol:i_mol+1]
    job=job.to_string(index=False)
    
    # Standard formation enthalpy
    HT_form = 0

    if job.strip() == 'HF':
        for i_ua in range(int(N_ua)):
           HOF_0K     = HOF_atoms(ua[i_ua])
           dH_298K_0K = dH_atoms(ua[i_ua])
           HT_form = HT_form + ua_N[i_ua] * ( HOF_0K - dH_298K_0K )
        
        HT_form = HT_form + (HT_mol - U0_mol) - U0_mol_AE

    # Output geometry
    if ( print_geom == 'true' ):
        geomfile.write(' {:5d}\n'.format(int(Nat)))
        geomfile.write(' Mol_{:05d}, charge={:5d}, multip={:5d}\n'.format(i_mol+1,charge,multip))
        for iat in range(Nat):
            geomfile.write(' {:4s}{:15.8f}{:15.8f}{:15.8f}\n'.format(sym[iat],float(X[iat]),float(Y[iat]),float(Z[iat])))

    # Output frequencies
    if ( print_freq == 'true' ):
        freq=mols['Frequencies'][i_mol:i_mol+1]
        freq=freq.to_string(index=False)
        freq=freq.strip().split(',')
        for f in freq:
            freqfile.write(' {:10.2f}'.format(float(f)))
        freqfile.write('\n')
    
    # Output atomization energy and formation enthalpy
    if job.strip() == 'AE':
        print(' {:5d}{:12.4f}{:12.4f}{:16.4f} -- Atomization Energy'.format(i_mol+1,U0_mol_AE*au2kcm,HT_form*au2kcm,exp))
    else:
        print(' {:5d}{:12.4f}{:12.4f}{:16.4f}'.format(i_mol+1,U0_mol_AE*au2kcm,HT_form*au2kcm,exp))

if ( print_geom == 'true' ):
    geomfile.close() 

if ( print_freq == 'true' ):
    freqfile.close() 
